# Task 2: Data Collection & Preprocessing

## Project
**UCI Optical Recognition of Handwritten Digits**

## Objective
Collect a public dataset containing at least 1,000 samples, clean the data, validate data quality, perform feature engineering, and document the complete preprocessing pipeline.

## Dataset
- Public source: UCI Machine Learning Repository
- Dataset: Optical Recognition of Handwritten Digits
- UCI dataset ID: 80
- UCI DOI: 10.24432/C50P49
- UCI full dataset size: 5,620 instances
- Features: 64 integer pixel attributes
- Pixel range: 0–16
- Classes: 10 digit classes (0–9)
- Project copy used: scikit-learn `load_digits()`, containing 1,797 samples
- Minimum required: 1,000 samples

The official UCI page states that the original dataset contains 5,620 instances and 64 integer features, with no missing values. The scikit-learn copy contains 1,797 samples and is a copy of the UCI handwritten-digits test dataset.

## Preprocessing steps
1. Load the public dataset.
2. Standardize column names.
3. Convert feature columns to numeric types.
4. Check and handle missing values using median imputation when present.
5. Detect and remove exact duplicate rows.
6. Validate pixel values against the documented 0–16 range.
7. Detect potential outliers using the IQR rule.
8. Retain IQR-flagged observations because unusual pixel patterns can represent legitimate handwriting.
9. Engineer:
   - `total_intensity`
   - `nonzero_pixels`
   - `mean_pixel`
   - `std_pixel`
   - `horizontal_symmetry_score`
10. Save the cleaned dataset.

## Results
- Raw samples: 1797
- Cleaned samples: 1797
- Missing cells before: 0
- Missing cells after: 0
- Duplicate rows found: 0
- Duplicate rows removed: 0
- Invalid pixel values found: 0
- Rows flagged by IQR outlier check: 998
- Final columns: 70
- Target classes: 10

## Files
- `data/digits_raw.csv` – raw project dataset
- `data/digits_cleaned.csv` – cleaned and feature-engineered dataset
- `preprocessing/preprocessing.py` – reproducible preprocessing script
- `notebook/data_preprocessing.ipynb` – notebook version
- `screenshots/` – output screenshots/charts
- `DATA_DOCUMENTATION.md` – data dictionary and pipeline documentation
- `requirements.txt` – Python dependencies

## How to run
```bash
pip install -r requirements.txt
python preprocessing/preprocessing.py
```

## Citation
Alpaydin, E. & Kaynak, C. (1998). Optical Recognition of Handwritten Digits. UCI Machine Learning Repository. DOI: 10.24432/C50P49.
