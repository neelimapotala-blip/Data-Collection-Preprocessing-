"""
Task 2 - Data Collection & Preprocessing
Dataset: UCI Optical Recognition of Handwritten Digits
Reproducible preprocessing pipeline.

Run:
    python preprocessing.py
"""

from pathlib import Path
import pandas as pd
import numpy as np
from sklearn.datasets import load_digits

BASE = Path(__file__).resolve().parents[1]
DATA_DIR = BASE / "data"

def main():
    # Collect public dataset through scikit-learn's copy of the UCI digits dataset.
    digits = load_digits(as_frame=False)
    X = pd.DataFrame(
        digits.data,
        columns=[f"pixel_{i+1:02d}" for i in range(64)]
    )
    df = X.copy()
    df["target"] = digits.target

    print("Initial shape:", df.shape)

    # 1. Standardize column names
    df.columns = (
        df.columns.str.strip()
                  .str.lower()
                  .str.replace(r"[^a-z0-9_]+", "_", regex=True)
    )

    # 2. Correct data types
    for col in df.columns:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    # 3. Missing-value handling
    missing_before = int(df.isna().sum().sum())
    numeric_cols = [c for c in df.columns if c != "target"]
    for col in numeric_cols:
        if df[col].isna().any():
            df[col] = df[col].fillna(df[col].median())
    missing_after = int(df.isna().sum().sum())

    # 4. Duplicate handling
    duplicates = int(df.duplicated().sum())
    df = df.drop_duplicates().reset_index(drop=True)

    # 5. Range validation for pixel values
    invalid = int(((df[numeric_cols] < 0) | (df[numeric_cols] > 16)).sum().sum())
    for col in numeric_cols:
        df[col] = df[col].clip(0, 16)

    # 6. Outlier check using IQR
    outlier_rows = set()
    for col in numeric_cols:
        q1, q3 = df[col].quantile([0.25, 0.75])
        iqr = q3 - q1
        if iqr != 0:
            low, high = q1 - 1.5 * iqr, q3 + 1.5 * iqr
            outlier_rows.update(df.index[(df[col] < low) | (df[col] > high)].tolist())

    # Outliers are retained because extreme pixel patterns can be valid handwriting.
    print("Rows flagged by IQR:", len(outlier_rows))

    # 7. Feature engineering
    pixel_cols = [f"pixel_{i+1:02d}" for i in range(64)]
    df["total_intensity"] = df[pixel_cols].sum(axis=1)
    df["nonzero_pixels"] = (df[pixel_cols] > 0).sum(axis=1)
    df["mean_pixel"] = df[pixel_cols].mean(axis=1)
    df["std_pixel"] = df[pixel_cols].std(axis=1)

    arr = df[pixel_cols].to_numpy().reshape(-1, 8, 8)
    symmetry = np.abs(
        arr[:, :, :4] - arr[:, :, 4:][:, :, ::-1]
    ).mean(axis=(1, 2))
    df["horizontal_symmetry_score"] = symmetry

    output = DATA_DIR / "digits_cleaned.csv"
    df.to_csv(output, index=False)

    print("\nPreprocessing completed.")
    print("Final shape:", df.shape)
    print("Missing values before:", missing_before)
    print("Missing values after:", missing_after)
    print("Duplicates found:", duplicates)
    print("Invalid pixel values:", invalid)
    print("Saved:", output)

if __name__ == "__main__":
    main()
