# Data Documentation

## 1. Dataset identification
**Name:** Optical Recognition of Handwritten Digits  
**Source:** UCI Machine Learning Repository  
**UCI ID:** 80  
**DOI:** 10.24432/C50P49  
**Domain:** Computer Science / image processing  
**Task:** Multiclass classification

## 2. Dataset description
Each record represents an 8×8 normalized handwritten-digit image. There are 64 pixel features and one target class. Pixel values are integers from 0 to 16 and the target contains digit labels 0–9.

The official UCI repository lists 5,620 instances. This project uses the reproducible scikit-learn copy of the UCI dataset, which contains 1,797 samples and therefore exceeds the project requirement of 1,000 samples.

## 3. Data quality
| Check | Result |
|---|---:|
| Initial samples | 1797 |
| Missing cells before | 0 |
| Missing cells after | 0 |
| Duplicate rows found | 0 |
| Duplicate rows removed | 0 |
| Invalid pixel values | 0 |
| IQR-flagged rows | 998 |
| Final samples | 1797 |

## 4. Column dictionary
- `pixel_01` to `pixel_64`: grayscale pixel intensity values, integer range 0–16.
- `target`: handwritten digit class, integer 0–9.
- `total_intensity`: sum of all 64 pixel intensities.
- `nonzero_pixels`: number of pixels with intensity greater than zero.
- `mean_pixel`: average pixel intensity.
- `std_pixel`: standard deviation of pixel intensities.
- `horizontal_symmetry_score`: mean absolute difference between mirrored left/right pixel positions; lower values indicate greater horizontal symmetry.

## 5. Preprocessing decisions
### Missing values
The dataset was checked for missing values. No missing cells were found in the project copy. The script nevertheless includes median imputation so the pipeline remains robust if missing values appear in a modified copy.

### Duplicates
Exact duplicate rows were checked and removed if present.

### Incorrect data types
All feature and target columns are explicitly converted to numeric values using safe coercion.

### Range validation
Pixel values are validated against the documented 0–16 range. Values outside the range are clipped after being counted.

### Outliers
IQR-based outlier detection is performed. Potential outliers are not automatically deleted because extreme pixel patterns can be valid characteristics of handwritten digits. This avoids unnecessarily removing legitimate observations.

### Feature engineering
Five additional features are created to summarize image intensity and shape characteristics.

## 6. Reproducibility
The complete pipeline is implemented in `preprocessing/preprocessing.py` and duplicated in `notebook/data_preprocessing.ipynb`.

## 7. Ethical/data note
This is a historical handwritten-digit image dataset used for machine-learning education and benchmarking. It does not represent a current population survey.
